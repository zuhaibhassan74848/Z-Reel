package com.zreels.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int red=Color.rgb(239,27,45), green=Color.rgb(55,185,235), bg=Color.rgb(5,5,5);
    LinearLayout root, content, feed; String code="+92"; String phone="";
    String[][] countries = COUNTRY_DATA;

    static final String[][] COUNTRY_DATA = new String[][]{
{"Pakistan","+92"},
{"India","+91"},
{"United States","+1"},
{"Canada","+1"},
{"United Kingdom","+44"},
{"United Arab Emirates","+971"},
{"Saudi Arabia","+966"},
{"Qatar","+974"},
{"Kuwait","+965"},
{"Bahrain","+973"},
{"Oman","+968"},
{"Turkey","+90"},
{"Iran","+98"},
{"Iraq","+964"},
{"Afghanistan","+93"},
{"Bangladesh","+880"},
{"Nepal","+977"},
{"Sri Lanka","+94"},
{"China","+86"},
{"Japan","+81"},
{"South Korea","+82"},
{"Malaysia","+60"},
{"Indonesia","+62"},
{"Singapore","+65"},
{"Thailand","+66"},
{"Australia","+61"},
{"New Zealand","+64"},
{"South Africa","+27"},
{"Nigeria","+234"},
{"Kenya","+254"},
{"Egypt","+20"},
{"Morocco","+212"},
{"Algeria","+213"},
{"Tunisia","+216"},
{"Libya","+218"},
{"Sudan","+249"},
{"Ethiopia","+251"},
{"France","+33"},
{"Germany","+49"},
{"Italy","+39"},
{"Spain","+34"},
{"Portugal","+351"},
{"Netherlands","+31"},
{"Belgium","+32"},
{"Switzerland","+41"},
{"Sweden","+46"},
{"Norway","+47"},
{"Denmark","+45"},
{"Finland","+358"},
{"Poland","+48"},
{"Russia","+7"},
{"Ukraine","+380"},
{"Greece","+30"},
{"Ireland","+353"},
{"Austria","+43"},
{"Czechia","+420"},
{"Romania","+40"},
{"Hungary","+36"},
{"Brazil","+55"},
{"Argentina","+54"},
{"Mexico","+52"},
{"Chile","+56"},
{"Colombia","+57"},
{"Peru","+51"},
{"Venezuela","+58"},
{"Bolivia","+591"},
{"Ecuador","+593"},
{"Uruguay","+598"},
{"Paraguay","+595"},
{"Costa Rica","+506"},
{"Panama","+507"},
{"Dominican Republic","+1"},
{"Jamaica","+1"},
{"Bahamas","+1"},
{"Philippines","+63"},
{"Vietnam","+84"},
{"Cambodia","+855"},
{"Myanmar","+95"},
{"Hong Kong","+852"},
{"Taiwan","+886"},
{"Israel","+972"},
{"Jordan","+962"},
{"Lebanon","+961"},
{"Syria","+963"},
{"Yemen","+967"},
{"Palestine","+970"},
{"Kazakhstan","+7"},
{"Uzbekistan","+998"},
{"Tajikistan","+992"},
{"Turkmenistan","+993"},
{"Kyrgyzstan","+996"},
{"Azerbaijan","+994"},
{"Georgia","+995"},
{"Armenia","+374"},
{"Mongolia","+976"},
{"Maldives","+960"},
{"Mauritius","+230"},
{"Seychelles","+248"},
{"Ghana","+233"},
{"Tanzania","+255"},
{"Uganda","+256"},
{"Zimbabwe","+263"},
{"Zambia","+260"},
{"Rwanda","+250"},
{"Somalia","+252"},
{"Senegal","+221"},
{"Cameroon","+237"},
{"Ivory Coast","+225"},
{"Angola","+244"},
{"Mozambique","+258"},
{"Namibia","+264"},
{"Botswana","+267"},
{"Malawi","+265"},
{"Madagascar","+261"},
{"Mali","+223"},
{"Niger","+227"},
{"Chad","+235"},
{"Benin","+229"},
{"Togo","+228"},
{"Sierra Leone","+232"},
{"Liberia","+231"},
{"Burkina Faso","+226"},
{"Guinea","+224"},
{"Gabon","+241"},
{"Congo","+242"},
{"DR Congo","+243"},
{"United Kingdom (Crown Dependencies)","+44"},
{"Iceland","+354"},
{"Malta","+356"},
{"Cyprus","+357"},
{"Luxembourg","+352"},
{"Estonia","+372"},
{"Latvia","+371"},
{"Lithuania","+370"},
{"Slovakia","+421"},
{"Slovenia","+386"},
{"Croatia","+385"},
{"Serbia","+381"},
{"Bosnia and Herzegovina","+387"},
{"Albania","+355"},
{"North Macedonia","+389"},
{"Moldova","+373"},
{"Bulgaria","+359"},
{"Belarus","+375"},
{"Montenegro","+382"},
{"Kosovo","+383"}
    };

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(14),dp(10),dp(14),dp(10));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);splash();new Handler().postDelayed(()->login(),1700);}
    void splash(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER);l.setOrientation(LinearLayout.VERTICAL);l.setBackgroundColor(bg);
      TextView z=tv("Z",64);z.setGravity(17);z.setTypeface(null,1);z.setTextColor(Color.WHITE);
      GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{red,skyBlue});g.setCornerRadius(dp(28));z.setBackground(g);l.addView(z,new LinearLayout.LayoutParams(dp(115),dp(115)));
      TextView n=tv("Z REELS",28);n.setGravity(17);n.setTypeface(null,1);l.addView(n,new LinearLayout.LayoutParams(-1,dp(70)));setContentView(l);}
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);TextView h=tv(title,25);h.setTypeface(null,1);h.setPadding(dp(20),dp(22),dp(20),dp(12));root.addView(h);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(8),dp(20),dp(20));root.addView(content,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void login(){base("Welcome to Z Reels 🔥");content.addView(tv("Create your account or login with your phone number.",16));
      Button country=btn("🌍  Pakistan  +92");country.setOnClickListener(v->countryPicker(country));content.addView(country,new LinearLayout.LayoutParams(-1,dp(58)));
      EditText p=new EditText(this);p.setHint("Phone number");p.setTextColor(Color.WHITE);p.setHintTextColor(Color.GRAY);p.setInputType(2);content.addView(p,new LinearLayout.LayoutParams(-1,dp(60)));
      Button send=btn("Send OTP");send.setBackgroundColor(red);send.setOnClickListener(v->{phone=p.getText().toString().trim(); if(phone.length()<5){p.setError("Enter a valid number");return;} otp();});content.addView(send,new LinearLayout.LayoutParams(-1,dp(58)));
      content.addView(tv("By continuing you agree to Z Reels terms and privacy policy.",12));}
    void countryPicker(Button target){ final Dialog d=new Dialog(this);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(16),dp(16),dp(16));l.setBackgroundColor(Color.rgb(18,18,18));
      TextView title=tv("Select country / region",20);l.addView(title);EditText search=new EditText(this);search.setHint("Search country");search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);l.addView(search);
      ListView list=new ListView(this);ArrayList<String> names=new ArrayList<>();for(String[] c:countries)names.add(c[0]+"   "+c[1]);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names){public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);t.setTextColor(Color.WHITE);t.setTextSize(16);t.setPadding(dp(8),dp(14),dp(8),dp(14));return t;}};list.setAdapter(a);l.addView(list,new LinearLayout.LayoutParams(-1,dp(430)));search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){String q=s.toString().toLowerCase();ArrayList<String> n=new ArrayList<>();for(String[] x:countries)if(x[0].toLowerCase().contains(q)||x[1].contains(q))n.add(x[0]+"   "+x[1]);a.clear();a.addAll(n);a.notifyDataSetChanged();}public void afterTextChanged(android.text.Editable e){}});list.setOnItemClickListener((par,v,pos,id)->{String s=((TextView)v).getText().toString();for(String[] c:countries)if(s.startsWith(c[0])){code=c[1];target.setText("🌍  "+c[0]+"  "+c[1]);break;}d.dismiss();});d.setContentView(l);Window w=d.getWindow();d.show();}
    void otp(){base("Verify your number");content.addView(tv("Enter the 6-digit OTP sent to\n"+code+" "+phone,17));EditText o=new EditText(this);o.setHint("6-digit OTP");o.setTextColor(Color.WHITE);o.setHintTextColor(Color.GRAY);o.setInputType(2);content.addView(o,new LinearLayout.LayoutParams(-1,dp(60)));Button v=btn("Verify OTP");v.setBackgroundColor(skyBlue);v.setOnClickListener(x->{if(o.getText().toString().equals("123456"))home();else o.setError("Demo OTP is 123456");});content.addView(v,new LinearLayout.LayoutParams(-1,dp(58)));content.addView(tv("Demo mode: real SMS delivery needs an SMS provider connected to the backend.",12));}
    void home(){base("Z Reels  🔴🟢");feed=new LinearLayout(this);feed.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(feed);content.addView(sv,new LinearLayout.LayoutParams(-1,0,1));addWelcome();Button up=btn("＋  Upload Reel");up.setBackgroundColor(red);up.setOnClickListener(v->pickVideo());content.addView(up,new LinearLayout.LayoutParams(-1,dp(58)));}
    void addWelcome(){TextView t=tv("🎬 Welcome to Z Reels\\n\\nWatch reels, upload your own videos and build your profile.",18);t.setGravity(17);feed.addView(t,new LinearLayout.LayoutParams(-1,dp(260)));}
    void pickVideo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,99);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==99&&c==RESULT_OK&&d!=null)addVideo(d.getData());}
    void addVideo(Uri u){VideoView v=new VideoView(this);v.setVideoURI(u);v.setOnPreparedListener(m->{m.setLooping(true);v.start();});feed.addView(v,new LinearLayout.LayoutParams(-1,dp(500)));feed.addView(tv("@you  •  My new Z Reel 🔥",16));}
}